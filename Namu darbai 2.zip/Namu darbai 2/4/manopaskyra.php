
<!-- <?php 


$vardas = $_GET["vardas"];
$slaptazodis = $_GET["slaptazodis"];


if ($vardas === 'admin' && $slaptazodis === '123456') { 
    echo 'Prisijungėte sėkmingai';
    } 
    else {
        
        header("HTTP/1.0 404 Not Found");
    
    }


?>


 -->

