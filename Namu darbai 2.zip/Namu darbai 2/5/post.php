<?php



    $spalva = $_GET['spalva'];
    $veiksmas = $_GET["veiksmas"];
    
    

    if ($spalva == "juoda"){
         echo '<body style="background-color:black">';
    }
    if ($spalva == "raudona"){
        echo '<body style="background-color:red">';
    }
    if ($spalva == "melyna"){
        echo '<body style="background-color:blue">';
    }

    
?>



